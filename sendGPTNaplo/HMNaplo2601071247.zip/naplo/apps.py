from django.apps import AppConfig


class NaploConfig(AppConfig):
    name = 'naplo'
